<?php
include_once('../class/class_login.php');	
$index = new login('','');
$index->keluar();
?>
